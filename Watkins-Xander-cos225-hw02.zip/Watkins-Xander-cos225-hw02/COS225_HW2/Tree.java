public class Tree {
    public int IDNumber;
    public int age;
    public String species_name;

    public Tree(int ID, int age, String species){
        IDNumber = ID;
        this.age = age;
        species_name = species;
    }
}
